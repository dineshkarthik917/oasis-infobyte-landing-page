# OIBSIP — Web Development & Designing — Level 1 Task 1

## Project
DevLaunch — Responsive Web Development Landing Page

## Technologies
- HTML5
- CSS3
- Responsive Design
- Basic JavaScript for mobile navigation

## Features
- Responsive navigation
- Hero section
- Feature cards
- About section
- Statistics
- Call-to-action section
- Smooth scrolling
- Hover animations
- Mobile menu
- Semantic HTML structure

## Run locally
Open `index.html` in a modern web browser.

## Internship
OASIS INFOBYTE — Web Development & Designing
Level 1 — Task 1
